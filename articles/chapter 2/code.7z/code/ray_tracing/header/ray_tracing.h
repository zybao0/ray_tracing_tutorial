//this header include all other headers
#pragma once
#include<core.h>
#include<objects/sphere.h>
#include<tools.h>
